package team.bdqnmanager.pojo;

/**
 * 根据操作者权限显示操作界面的实体
 * @author ddd
 *
 */
public class Menu {
	//功能名称
	private String name;
	//图标
	private String icon;
	//url地址
	private String url;
	//父集
	private Menu parent;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Menu getParent() {
		return parent;
	}
	public void setParent(Menu parent) {
		this.parent = parent;
	}
}
