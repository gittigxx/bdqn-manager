package team.bdqnmanager.pojo;

import java.util.Date;


/**
 * 用户详细详细实体
 * @author ddd
 *
 */
public class User_detailed {
	//用户地址
	private String address;
	//用户诞辰
	private Date birthday;
	//邮箱
	private String email;
	//性别
	private Gender gender;
	//电话号码
	private String phone;
	//学历
	private Diploma diploma;
	
	public enum Gender{
		/**
		 * 男
		 */
		MALE,
		/**
		 * 女
		 */
		FEMALE
	}
	/**
	 * 学历
	 */
	public enum Diploma {
		/** 小学 */
		PRIMARYSCHOOL,
		/** 初中 */
		JUNIORHIGHTSCHOOL,
		/** 高中 */
		SENIORHIGHSCHOOL,
		/** 大专 */
		JUNIORCOLLEGE,
		/** 本科 */
		UNDERGRADUATE,
		/** 硕士 */
		MASTER,
		/** 博士 */
		LEARNED,
		/** 其他 */
		OTHER;
		/**
		 * 获取学历
		 * 
		 * @return 学历
		 */
		@Override
		public String toString() {
			switch (this) {
			case PRIMARYSCHOOL:
				return "小学";
			case JUNIORHIGHTSCHOOL:
				return "初中";
			case SENIORHIGHSCHOOL:
				return "高中";
			case JUNIORCOLLEGE:
				return "大专";
			case UNDERGRADUATE:
				return "本科";
			case MASTER:
				return "硕士";
			case LEARNED:
				return "博士";
			default:
				return "其它";
			}
		}
}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Diploma getDiploma() {
		return diploma;
	}
	public void setDiploma(Diploma diploma) {
		this.diploma = diploma;
	}
}