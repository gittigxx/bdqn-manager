package team.bdqnmanager.pojo;

import java.util.Date;

/**
 * 登录用户基本信息
 * @author ddd
 *
 */
public class User_BaseInfo {
	//id
	private Integer id;
	//用户名
	private String name;
	//密码
	private String password;
	//账号创建时间
	private Date createTime;
	//头像
	private String photo;
	//用户角色
	private Role role;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
}
