package team.bdqnmanager.pojo;

import java.util.Set;

/**
 * 登录角色实体
 * @author ddd
 *
 */
public class Role {
	//角色类型
	private RoleCode rolecode;
	//角色描述
	private String description;
	//角色对应的操作权限
	private Set<Menu> menus;
	public enum RoleCode{
		/**
		 * 学生
		 */
		student,
		/**
		 * 班主任
		 */
		bTeacher,
		/**
		 * 教员
		 */
		jTeacher,
		/**
		 * 班主任manager
		 */
		bTeacherManager,
		/**
		 * 教员manager
		 */
		jTeacherManager,
		/**
		 * 最高权限
		 */
		root
	}
}
