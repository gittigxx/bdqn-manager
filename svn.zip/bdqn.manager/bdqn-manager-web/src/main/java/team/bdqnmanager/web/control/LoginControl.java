package team.bdqnmanager.web.control;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import team.bdqnmanager.web.util.VerifyCodeUtils;

@Controller
public class LoginControl {
	@RequestMapping("image")
	public void captchaImage(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setHeader("Pragma", "No-cache");  
        response.setHeader("Cache-Control", "no-cache");  
        response.setDateHeader("Expires", 0);  
        response.setContentType("image/jpg");
          
        //生成随机字串  
        String verifyCode = VerifyCodeUtils.generateVerifyCode(4);  
        //存入会话session  
        HttpSession session = request.getSession(true);  
        //删除以前的
        session.removeAttribute("verifyCode");
        session.setAttribute("verifyCode", verifyCode.toLowerCase());  
        //生成图片  
        int width = 220, height = 50;
        VerifyCodeUtils.outputImage(width, height, response.getOutputStream(), verifyCode);  
	}
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public void login(){
		
	}
	@RequestMapping(value="login",method=RequestMethod.POST)
	public void Login(){
		
	}
}
