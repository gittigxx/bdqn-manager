package team.bdqnmanager.web.control;
import java.io.IOException;  

import javax.servlet.ServletException;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import team.bdqnmanager.web.util.VerifyCodeUtils;

/**
 * <p><b>AuthImage Description:</b> (验证码)</p>
 * <b>DATE:</b> 2016年6月2日 下午3:53:12
 */
@Controller
public class AuthImage{
	@RequestMapping("image")
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("请求到达");
        
    }  
	@RequestMapping("loginguide")
	public String imageguide(){
		return "login";
	}
	@RequestMapping("login")
	public String login(){
		System.out.println("登录成功");
		return "sdf";
	}
} 