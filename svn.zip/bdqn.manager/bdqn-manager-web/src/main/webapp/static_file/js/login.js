var loginfunction = function() {
	/*
	 * 登陆页面的初始化
	 */
	var loginvalidate = function() {
		var loginForm = $("#login-form");
    	loginForm.validate({
            errorElement: "span", // default input error message container
            errorClass: "help-block", // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            rules: {
                username: {
                    required: true
                },
                password: {
                    required: true
                },
                captcha: {
                    required: true
                }
            },

            messages: {
                username: {
                    required: "用户名不能为空"
                },
                password: {
                    required: "密码不能为空"
                },
                captcha: {
                    required: "验证码不能为空"
                }
            },
            highlight: function(element) { // hightlight error inputs
                $(element).closest(".form-group").addClass("has-error");
            },
            success: function(label) {
                label.closest(".form-group").removeClass("has-error");
                label.remove();
            },
            submitHandler: function(form) {
                // 显示遮罩
                App.blockUI({
                    target: ".content",
                    animate: true
                });
                form.submit();
            }
        });
    	$("#login").click(function(){
			if (loginForm.validate().form()) {
				
                    //显示遮罩
                    App.blockUI({
                        target: ".content",
                        animate: true
                    });
                    loginForm.submit(); //form validation success, call ajax form submit
             }
			console.log("验证没通过");
		})
	};
	
	var captcha=function(){
		$("#captcha").click(function(){
			console.log("captcha");
			$("#captcha").attr("src","image?"+Math.random());
		});
	};
	return {
		init : function() {
			loginvalidate();
			captcha();
		}
	};
}();

$(function() {
	loginfunction.init();
});